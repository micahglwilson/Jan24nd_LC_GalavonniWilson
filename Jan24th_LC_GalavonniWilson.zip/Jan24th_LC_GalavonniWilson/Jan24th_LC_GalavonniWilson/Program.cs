﻿// January 24, 2024 LC
// Galavonni Wilson 113506288

/* for loops
while loops
break continue
break: stop the loop
continue: skip rest of loop body and goes to post processing
 */

for (int i=50; i<100; i=i+1)
{
    if (i== 60)
    {
        continue;// stop


    }

    //Console.WriteLine(i);
}


Console.ReadLine();

//while
int n;
n = 50;
while (n<=100)
{
    Console.WriteLine(n);
    n = n + 1;
}



